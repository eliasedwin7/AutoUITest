import json
import pyautogui
import cv2
import numpy as np
from stable_baselines3 import DQN
from stable_baselines3.common.env_checker import check_env
import gym

class GenericUIEnv(gym.Env):
    def __init__(self, config_file):
        # Load the configuration file
        with open(config_file, 'r') as file:
            self.config = json.load(file)
        self.elements = {el['name']: el for el in self.config['elements']}
        self.tests = self.config['tests']
        self.current_test = None

    def reset(self):
        """Reset environment to the initial state."""
        if not self.tests:
            return None  # No more tests to execute
        self.current_test = self.tests.pop(0)
        return np.array(pyautogui.screenshot())

    def find_element_coordinates(self, element_image):
        """Locate an element's coordinates using OpenCV template matching."""
        screenshot = pyautogui.screenshot()
        screenshot = np.array(screenshot)

        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        template = cv2.imread(element_image, 0)

        result = cv2.matchTemplate(gray_screenshot, template, cv2.TM_CCOEFF_NORMED)
        _, _, _, max_loc = cv2.minMaxLoc(result)

        h, w = template.shape[:2]
        return max_loc[0] + w // 2, max_loc[1] + h // 2

    def step(self, action_index):
        """Perform an action and return the new state, reward, done status."""
        step = self.current_test['steps'][action_index]
        element = self.elements[step['element_name']]
        action = step['action']

        # Find the coordinates of the element using its image
        x, y = self.find_element_coordinates(element['element_image'])

        if action == "click":
            pyautogui.click(x, y)

        # Update the new state
        new_state = np.array(pyautogui.screenshot())

        # Compare with expected output
        expected_image = cv2.imread(self.current_test['expected_output'])
        reward = 1 if self.is_goal_achieved(new_state, expected_image) else -0.1
        done = reward == 1

        return new_state, reward, done, {}

    def is_goal_achieved(self, current_state, expected_state):
        """Check if the goal is achieved by comparing the current and expected images."""
        result = cv2.matchTemplate(current_state, expected_state, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(result)
        return max_val > 0.9

    def render(self, mode='human'):
        pass

    def close(self):
        pass

# Load JSON configuration and set up environment
env = GenericUIEnv("config.json")

# Validate the environment setup
check_env(env)

# Train with a reinforcement learning algorithm like DQN
model = DQN("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=10000)

# Save the trained model
model.save("generic_ui_rl_agent")

# Test the model
obs = env.reset()
while obs is not None:
    action, _states = model.predict(obs)
    obs, reward, done, info = env.step(action)
    if done:
        obs = env.reset()
