import json
import os
import pyautogui
from PIL import Image, ImageChops
import logging
import time
import mss
import pygetwindow as gw

# Set up logging
logging.basicConfig(filename='gui_tester.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Directories for screenshots and differences
screenshots_dir = "replay_screenshots"
differences_dir = "differences"
os.makedirs(screenshots_dir, exist_ok=True)
os.makedirs(differences_dir, exist_ok=True)

# Application window title and desired fixed position
application_window_title = "OMS Focus 8.0.6 - ICMS Evaluation"
fixed_position = {"left": 100, "top": 100, "width": 1800, "height": 1080}

def move_window_to_fixed_position(title, x, y, width, height):
    """Move the window with the given title to a fixed position and size."""
    try:
        window = gw.getWindowsWithTitle(title)[0]
        window.moveTo(x, y)
        window.resizeTo(width, height)
        return {
            "left": x,
            "top": y,
            "width": width,
            "height": height
        }
    except IndexError:
        raise ValueError(f"Error: Window '{title}' not found.")

# Move the application window to the fixed position before testing
try:
    region_coordinates = move_window_to_fixed_position(
        application_window_title,
        fixed_position["left"],
        fixed_position["top"],
        fixed_position["width"],
        fixed_position["height"]
    )
except ValueError as e:
    print(e)
    raise

# Function to capture a screenshot of the application's region
def take_screenshot(name):
    """Capture a screenshot within the defined application region and save it."""
    with mss.mss() as sct:
        screenshot = sct.grab((region_coordinates['left'], region_coordinates['top'],
                               region_coordinates['width'], region_coordinates['height']))
        screenshot_path = os.path.join(screenshots_dir, name)
        mss.tools.to_png(screenshot.rgb, screenshot.size, output=screenshot_path)
    return screenshot_path

class AdvancedGUITester:
    def __init__(self, threshold=0.8):
        self.threshold = threshold
        self.logs = []

    def click(self, x, y, description="Click"):
        """Simulate a click within the application window and log the action."""
        screen_x = region_coordinates['left'] + x
        screen_y = region_coordinates['top'] + y

        pyautogui.click(screen_x, screen_y)
        self.logs.append(f"{description} at ({screen_x}, {screen_y})")
        logging.info(f"{description} at ({screen_x}, {screen_y})")
        time.sleep(1)

    def press_key(self, key, description="Key Press"):
        """Simulate a key press and log the action."""
        pyautogui.press(key)
        self.logs.append(f"{description} '{key}'")
        logging.info(f"{description} '{key}'")
        time.sleep(1)

    def screenshot(self, file_name, description="Screenshot"):
        """Take a screenshot of the application's region and save it."""
        screenshot_path = take_screenshot(file_name)
        self.logs.append(f"{description} saved as {file_name}")
        logging.info(f"{description} saved as {file_name}")
        time.sleep(1)
        return screenshot_path

    def compare_images(self, image1_path, image2_path):
        """Compare two images and return True if they are at least threshold% similar."""
        img1 = Image.open(image1_path).convert('RGB')
        img2 = Image.open(image2_path).convert('RGB')

        if img1.size != img2.size:
            img2 = img2.resize(img1.size)

        diff = ImageChops.difference(img1, img2)
        if diff.getbbox():
            # Save the difference if images differ
            diff_name = f"diff_{os.path.basename(image2_path)}"
            diff_path = os.path.join(differences_dir, diff_name)
            diff.save(diff_path)
            return False
        return True

    def run_actions_and_compare(self, json_file_path):
        """Run actions recorded in the JSON file and compare screenshots."""
        with open(json_file_path, 'r') as file:
            actions_data = json.load(file)
            actions = actions_data.get('actions', [])

        for action in actions:
            action_type = action.get('type')
            description = action.get('description')
            new_screenshot = f'{description.replace(" ", "_").replace(".", "")}_{int(time.time())}.png'

            if action_type == 'click':
                self.click(action['x'], action['y'], description)
                new_screenshot_path = self.screenshot(new_screenshot, description)

            elif action_type == 'key':
                self.press_key(action['key'], description)
                new_screenshot_path = self.screenshot(new_screenshot, description)

            reference_screenshot = action.get('screenshot')
            if reference_screenshot and not self.compare_images(reference_screenshot, new_screenshot_path):
                logging.warning(f"Difference found for {description}. Reference: {reference_screenshot}, New: {new_screenshot_path}")
            else:
                logging.info(f"No significant differences found for {description}. Reference matches new screenshot.")

# Example usage
if __name__ == "__main__":
    tester = AdvancedGUITester()
    tester.run_actions_and_compare("filtered_recorded_actions.json")
