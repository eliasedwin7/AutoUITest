import json
import time
import mss
import os
import pygetwindow as gw
from pynput import mouse, keyboard
from tkinter import Tk, Canvas

# Initialize an empty list to store recorded actions
recorded_actions = []

# Directory to store screenshots
screenshots_dir = "screenshots"
os.makedirs(screenshots_dir, exist_ok=True)

def move_window_to_fixed_position(title, x, y, width, height):
    """Move the window with the given title to a fixed position and size."""
    try:
        window = gw.getWindowsWithTitle(title)[0]
        window.moveTo(x, y)
        window.resizeTo(width, height)
        return {
            "left": x,
            "top": y,
            "width": width,
            "height": height
        }
    except IndexError:
        raise ValueError(f"Error: Window '{title}' not found.")

# Application window title and the desired fixed position and size
application_window_title = "OMS Focus 8.0.6 - ICMS Evaluation"
fixed_position = {"left": 100, "top": 100, "width": 1800, "height": 1080}

# Move the application window to the fixed position
region_coordinates = move_window_to_fixed_position(
    application_window_title,
    fixed_position["left"],
    fixed_position["top"],
    fixed_position["width"],
    fixed_position["height"]
)

# Function to map coordinates to the application window region
def map_to_application(x, y):
    """Map the given coordinates to the application window region."""
    return {
        'x': max(region_coordinates['left'], min(x, region_coordinates['left'] + region_coordinates['width'])),
        'y': max(region_coordinates['top'], min(y, region_coordinates['top'] + region_coordinates['height']))
    }

# Function to capture a screenshot of the application window region
def take_screenshot(name):
    """Capture a region-specific screenshot and save it with a given name."""
    with mss.mss() as sct:
        screenshot = sct.grab((region_coordinates['left'], region_coordinates['top'], region_coordinates['width'], region_coordinates['height']))
        screenshot_path = os.path.join(screenshots_dir, name)
        mss.tools.to_png(screenshot.rgb, screenshot.size, output=screenshot_path)
    return screenshot_path

# Mouse listener callbacks
def on_click(x, y, button, pressed):
    """Record clicks within the application window and take a screenshot."""
    coords = map_to_application(x, y)
    if pressed:
        description = f'Clicked {button}'
        screenshot_name = f'{description.replace(" ", "_").replace(".", "")}_{int(time.time())}.png'
        screenshot_path = take_screenshot(screenshot_name)
        recorded_actions.append({
            'type': 'click',
            'description': description,
            'x': coords['x'],
            'y': coords['y'],
            'screenshot': screenshot_path
        })

def on_scroll(x, y, dx, dy):
    """Record scroll events within the application window and take a screenshot."""
    coords = map_to_application(x, y)
    description = 'Scrolled'
    screenshot_name = f'{description.replace(" ", "_").replace(".", "")}_{int(time.time())}.png'
    screenshot_path = take_screenshot(screenshot_name)
    recorded_actions.append({
        'type': 'scroll',
            'description': description,
            'x': coords['x'],
            'y': coords['y'],
            'amount': dy,
            'screenshot': screenshot_path
        })

def on_key_press(key):
    """Record key presses and take a screenshot."""
    description = f'Pressed key {key}'
    screenshot_name = f'{description.replace(" ", "_").replace(".", "")}_{int(time.time())}.png'
    screenshot_path = take_screenshot(screenshot_name)
    try:
        recorded_actions.append({
            'type': 'key',
            'description': description,
            'key': key.char,
            'screenshot': screenshot_path
        })
    except AttributeError:
        recorded_actions.append({
            'type': 'key',
            'description': f'Pressed special key {key}',
            'key': str(key),
            'screenshot': screenshot_path
        })

# Function to save the recorded actions and region to a JSON file
def save_actions_to_json(output_file, region):
    """Save the recorded actions to a JSON file, including region coordinates."""
    with open(output_file, 'w') as f:
        json.dump({'region': region, 'actions': recorded_actions}, f, indent=4)
    print(f"Actions and region coordinates saved to {output_file}")

# Start the mouse and keyboard listeners
def start_recording(output_file):
    """Start recording mouse and keyboard actions, mapping coordinates to the application window region."""
    mouse_listener = mouse.Listener(on_click=on_click, on_scroll=on_scroll)
    keyboard_listener = keyboard.Listener(on_press=on_key_press)

    # Start the listeners
    mouse_listener.start()
    keyboard_listener.start()

    # Keep the listeners active for 30 seconds or until stopped
    try:
        time.sleep(30)  # Adjust as needed
    except KeyboardInterrupt:
        pass
    finally:
        # Stop listeners
        mouse_listener.stop()
        keyboard_listener.stop()
        # Save the actions with the region coordinates
        save_actions_to_json(output_file, region_coordinates)

# Brush Tool Implementation
class BrushTool:
    def __init__(self):
        self.root = Tk()
        self.canvas = Canvas(self.root, width=800, height=600)
        self.canvas.pack()
        self.rect = None
        self.start_x, self.start_y = None, None

        self.canvas.bind("<ButtonPress-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_rect)
        self.canvas.bind("<ButtonRelease-1>", self.end_draw)

    def start_draw(self, event):
        """Start drawing a rectangle."""
        self.start_x, self.start_y = event.x, event.y
        self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, event.x, event.y, outline='red')

    def draw_rect(self, event):
        """Update the rectangle dimensions while dragging."""
        self.canvas.coords(self.rect, self.start_x, self.start_y, event.x, event.y)

    def end_draw(self, event):
        """Finalize the rectangle drawing."""
        print(f"Region captured: ({self.start_x}, {self.start_y}) to ({event.x}, {event.y})")

    def run(self):
        """Run the brush tool GUI."""
        self.root.mainloop()

# Example usage of the brush tool
if __name__ == "__main__":
    start_recording("filtered_recorded_actions.json")
    brush_tool = BrushTool()
    brush_tool.run()
